#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 11:58:50 2021

@author: lzdeng
"""
import numpy as np
import re

WASH=1;
VALVE_NUMBER=['23','22','21','20','19','18','17','16','108','109','110','111','104','105','106','107']
replacements_WaitTime =['WaitTimeVal01','WaitTimeVal02','WaitTimeVal03','WaitTimeVal04','WaitTimeVal05','WaitTimeVal06','WaitTimeVal07','WaitTimeVal08','WaitTimeVal09','WaitTimeVal10','WaitTimeVal11','WaitTimeVal12','WaitTimeVal13','WaitTimeVal14','WaitTimeVal15','WaitTimeVal16']



PATH='/Users/lzdeng/Documents/Automatic fluidics system/flow rate calibration sheets/20210325/target flow rate 145'

PATH_input_file_WaitTime=PATH+'/update variable template.mac'
PATH_output_file_WaitTime=PATH+'/update variable.mac'
PATH_input_file_Pressue=PATH+'/macros for ND Acquisition input'
PATH_output_file_Pressue=PATH+'/macros for ND Acquisition output'


if WASH==1:
    WaitTime=np.full([16,1],35)
    WaitTime[13,0]=65
else:
    WaitTime=np.load(PATH+'/WaitTime.npy',allow_pickle=True)

pr_set_channels=np.load(PATH+'/pr_set_channels.npy',allow_pickle=True)

pr_set_channels_hex=np.empty(16,dtype=object)
for i in range (16):
    pr_set_channels_hex[i]=hex(pr_set_channels[i]).upper()
    
replacements_ValveNum_hex=np.empty(16,dtype=object)
for i in range (16):
    replacements_ValveNum_hex[i]=hex(int(VALVE_NUMBER[i])).upper()




with open(PATH_input_file_WaitTime,encoding='utf-8') as infile, open(PATH_output_file_WaitTime, 'w+',encoding='utf-8') as outfile:
    for line in infile:
        for i, src in enumerate(replacements_WaitTime):
            line = line.replace(src, src+'='+str(int(np.ceil(WaitTime[i]))))
            
        outfile.write(line)
        
infile.close()
outfile.close()        

for i in range (16):
    i=i+1
    PATH_input_file_Pressue_temp=PATH_input_file_Pressue+'/channel_'+str(i)+'.mac'
    PATH_output_file_Pressue_temp=PATH_output_file_Pressue+'/channel_'+str(i)+'.mac'
    
    with open(PATH_input_file_Pressue_temp,encoding='utf-8') as infile, open(PATH_output_file_Pressue_temp, 'w+',encoding='utf-8') as outfile:
        for line in infile:
            line = line.replace('Pressure_HEX','"'+'\\x78'+'\\x'+pr_set_channels_hex[i-1][2:]+'"')
            outfile.write(line)
    infile.close()
    outfile.close() 