#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 30 15:41:36 2021

@author: lzdeng
"""


import sys
import numpy as np
from numpy import savetxt
import washing_and_priming as wap
import auto_calibration
import calibration_verification_with_DB as cv_DB
import flow_rate_conversion_calculator as frcc
import run_individual_channel
import time
import re

from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QTabWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QFormLayout,
    QWidget,
    QPushButton,
    QFileDialog,
    QRadioButton,
    QLineEdit,
    QTextEdit,
    QTableView,
    QComboBox,
    QLabel,
    QSizePolicy,
    QLayout,
)


from PyQt5.QtGui import (
    QPalette,
    QColor,

)


from PyQt5.QtCore import (
    Qt,
    pyqtSignal,
    QRect,
)


from PyQt5 import QtCore


class TableModel(QtCore.QAbstractTableModel):
    
    def __init__(self, data):
        super(TableModel, self).__init__()
        self._data = data

    def data(self, index, role):
        if role == Qt.DisplayRole:

            return self._data[index.row()][index.column()]

    def rowCount(self, index):

        return len(self._data)

    def columnCount(self, index):

        return len(self._data[0])
    
    

     
     
class Window(QWidget):
    
    valueChanged = pyqtSignal(str)
    textEdit = QTextEdit() 
    set_pressure=[127]*16
    
    
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Fluidics system calibration")
        self.resize(1000, 600) 
        
        self.valueChanged.connect(self.on_value_changed) 
                     
          
        # Create a top-level layout
        layout = QVBoxLayout()
        self.setLayout(layout)
        # Create the tab widget with two tabs
        global tabs
        tabs = QTabWidget()
        tabs.addTab(self.setupTabUI(), "Setup")
        tabs.addTab(self.calibrationTabUI(), "Calibration")
        tabs.addTab(self.calibration_verificationTabUI(), "Calibration verification")
        tabs.addTab(self.run_single_channelTabUI(), "Run single channel")
        
        layout.addWidget(tabs)
        layout.addWidget(self.textEdit)
        #layout.setSizeConstraint(QLayout.SetFixedSize)
        
        tabs.currentChanged.connect(self.updateSizes)

    def updateSizes(self):
        for i in range(tabs.count()):
            tabs.widget(i).setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
    
        current = tabs.currentWidget()
        current.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Maximum)
     
        
    @QtCore.pyqtSlot(str)
    def on_value_changed(self, value):
      self.textEdit.append("Value: {}".format(value))
      
        
    def setupTabUI(self):
        """Create the Setup page UI."""
        setupTab = QWidget()
        
        layout = QVBoxLayout()
        washing_and_priming_btn = QPushButton('Washing and Priming')
        washing_and_priming_btn.clicked.connect(self.washing_and_priming)  # Connect clicked to greeting()
        layout.addWidget(washing_and_priming_btn)
        
        global save_directory
        save_directory = QLineEdit()
        
        save_directory.setText('/Users/lzdeng/Documents/Automatic fluidics system/flow rate calibration sheets/20210824/target flow rate 190')
        
        open_file_btn = QPushButton("Save")
        open_file_btn.clicked.connect(self.open)
        
        layout.addWidget(save_directory)
        layout.addWidget(open_file_btn)
        
        global table_0
        table_0 =QTableView()
        layout.addWidget(table_0)
        maximum_flow_rate=[[0,0,0,0],[0,0,0,0]]
        model = TableModel(maximum_flow_rate)
        table_0.setModel(model)
        
        setupTab.setLayout(layout)
        return setupTab
    
    
    
    def open(self):
        
        path = QFileDialog.getExistingDirectory(self, 'Choose directory to save the calibration data')
        if path != ('', ''):
            self.valueChanged.emit("File path: "+str(path))            
            time.sleep(1)
            save_directory.setText(path)
            
            
    def washing_and_priming(self):
        ave_flow_rate, flow_rate_all=wap.washing_and_priming()
        self.valueChanged.emit("Average flow rate: "+str(ave_flow_rate))
        time.sleep(1)
        self.model = TableModel(flow_rate_all)
        table_0.setModel(self.model)
           

    def calibrationTabUI(self):
        """Create the Calibration page UI."""
        calibrationTab = QWidget()
        
        main_layout=QVBoxLayout()
        radio_btn_layout = QGridLayout()
        formLayout = QFormLayout()
        calibration_res_layout=QHBoxLayout()
        combobox_layout=QHBoxLayout()
        table_layout=QHBoxLayout()
        
        
        
        ### radiobutton to select calibration flow rate ###
        radiobutton = QRadioButton("140 ul/min")
        #radiobutton.setChecked(True)
        radiobutton.calibrationFlowRate = "calibration flow rate 140 ul/min "
        radiobutton.calibrationFlowRate_uint_8=145
        radiobutton.startPressure_uint_8_small1=40
        radiobutton.stopPressure_uint_8_small1=150
        radiobutton.stepPressure_uint_8_small1=5
        radiobutton.startPressure_uint_8_small2=50
        radiobutton.stopPressure_uint_8_small2=160
        radiobutton.stepPressure_uint_8_small2=5
        radiobutton.startPressure_uint_8_DB=40
        radiobutton.stopPressure_uint_8_DB=100
        radiobutton.stepPressure_uint_8_DB=1
        radiobutton.startPressure_uint_8_PBS=40
        radiobutton.stopPressure_uint_8_PBS=127
        radiobutton.stepPressure_uint_8_PBS=1
        radiobutton.toggled.connect(self.onClicked_1)
        radio_btn_layout.addWidget(radiobutton, 0, 0)

        radiobutton = QRadioButton("600 ul/min")
        radiobutton.calibrationFlowRate = "calibration flow rate 600 ul/min"
        radiobutton.calibrationFlowRate_uint_8=190
        radiobutton.startPressure_uint_8_small1=60
        radiobutton.stopPressure_uint_8_small1=100
        radiobutton.stepPressure_uint_8_small1=5
        radiobutton.startPressure_uint_8_small2=70
        radiobutton.stopPressure_uint_8_small2=110
        radiobutton.stepPressure_uint_8_small2=5
        radiobutton.startPressure_uint_8_DB=80
        radiobutton.stopPressure_uint_8_DB=140
        radiobutton.stepPressure_uint_8_DB=1
        radiobutton.startPressure_uint_8_PBS=60
        radiobutton.stopPressure_uint_8_PBS=130
        radiobutton.stepPressure_uint_8_PBS=1
        radiobutton.toggled.connect(self.onClicked_1)
        radio_btn_layout.addWidget(radiobutton, 0, 1)

        radiobutton = QRadioButton("1000 ul/min")
        radiobutton.calibrationFlowRate = "calibration flow rate 1000 ul/min"
        radiobutton.calibrationFlowRate_uint_8=225
        radiobutton.startPressure_uint_8_small1=90
        radiobutton.stopPressure_uint_8_small1=130
        radiobutton.stepPressure_uint_8_small1=2
        radiobutton.startPressure_uint_8_small2=130
        radiobutton.stopPressure_uint_8_small2=170
        radiobutton.stepPressure_uint_8_small2=2
        radiobutton.startPressure_uint_8_DB=110
        radiobutton.stopPressure_uint_8_DB=170
        radiobutton.stepPressure_uint_8_DB=1
        radiobutton.startPressure_uint_8_PBS=90
        radiobutton.stopPressure_uint_8_PBS=130
        radiobutton.stepPressure_uint_8_PBS=1
        radiobutton.toggled.connect(self.onClicked_1)
        radio_btn_layout.addWidget(radiobutton, 0, 2)
        
        
        ### retrieve calibration parameters ###
        global l1_start 
        l1_start = QLineEdit()
        l1_start.setText("40")

        global l1_stop 
        l1_stop = QLineEdit()
        l1_stop.setText("150")
       
        global l1_step 
        l1_step = QLineEdit()
        l1_step.setText("5")
        
        l1_vbox=QHBoxLayout()
        l1_vbox.addWidget(l1_start)
        l1_vbox.addWidget(l1_stop)
        l1_vbox.addWidget(l1_step)   
        
        
        global l2_start 
        l2_start = QLineEdit()
        l2_start.setText("50")
        
        global l2_stop 
        l2_stop = QLineEdit()
        l2_stop.setText("160")
        
        global l2_step 
        l2_step = QLineEdit()
        l2_step.setText("5")
        
        
        l2_vbox=QHBoxLayout()
        l2_vbox.addWidget(l2_start)
        l2_vbox.addWidget(l2_stop)
        l2_vbox.addWidget(l2_step) 
        
        
        global l3_start 
        l3_start = QLineEdit()
        l3_start.setText("40")
        
        global l3_stop 
        l3_stop = QLineEdit()
        l3_stop.setText("100")
        
        global l3_step 
        l3_step = QLineEdit()
        l3_step.setText("1")
        
        
        l3_vbox=QHBoxLayout()
        l3_vbox.addWidget(l3_start)
        l3_vbox.addWidget(l3_stop)
        l3_vbox.addWidget(l3_step) 
        

        global l4_start 
        l4_start = QLineEdit()
        l4_start.setText("40")
        
        global l4_stop 
        l4_stop = QLineEdit()
        l4_stop.setText("127")
        
        global l4_step 
        l4_step = QLineEdit()
        l4_step.setText("1")
        
        
        l4_vbox=QHBoxLayout()
        l4_vbox.addWidget(l4_start)
        l4_vbox.addWidget(l4_stop)
        l4_vbox.addWidget(l4_step)

        
        formLayout.addRow("Calibration range for channel #1-12, #16", l1_vbox)
        formLayout.addRow("Calibration range for channel #15", l2_vbox)
        formLayout.addRow("Calibration range for channel #13 (Displacement Buffer reservoir)", l3_vbox)
        formLayout.addRow("Calibration range for channel #14 (PBS reservoir)", l4_vbox)        
        
        main_layout.addLayout(radio_btn_layout)
        main_layout.addLayout(formLayout)
        
        
        global start_calibration_btn
        start_calibration_btn=QPushButton('Start calibration')        
        
        self.flow_rate=145         
        self.calibration_parameters=(40,150,5,50,160,5,40,100,1,40,127,1)
        
                 
        start_calibration_btn.clicked.connect(self.start_auto_calibration)
                
        
        confirm_calibration_parameters_btn=QPushButton('Save calibration parameters')
        confirm_calibration_parameters_btn.clicked.connect(self.get_calibration_parameters)

        main_layout.addWidget(confirm_calibration_parameters_btn)
        main_layout.addWidget(start_calibration_btn)        
        
        show_coarse_calibration_btn=QPushButton("Coarse calibration data")
        show_coarse_calibration_btn.clicked.connect(self.get_coarse_calibration_data)
        show_fine_calibration_btn=QPushButton("Fine calibration data")
        show_fine_calibration_btn.clicked.connect(self.get_fine_calibration_data)               
        show_pr_set_all_btn=QPushButton("Calibrated set_pressure")
        show_pr_set_all_btn.clicked.connect(self.get_and_show_set_pressure)
        
        calibration_res_layout.addWidget(show_coarse_calibration_btn)
        calibration_res_layout.addWidget(show_fine_calibration_btn)
        calibration_res_layout.addWidget(show_pr_set_all_btn)
                
        main_layout.addLayout(calibration_res_layout)    

    
        global cb_coarse_calibration
        cb_coarse_calibration=QComboBox()
        cb_coarse_calibration.addItem("Channel #1")
        cb_coarse_calibration.addItem("Channel #2")
        cb_coarse_calibration.addItem("Channel #3")
        cb_coarse_calibration.addItem("Channel #4")
        cb_coarse_calibration.addItem("Channel #5")
        cb_coarse_calibration.addItem("Channel #6")
        cb_coarse_calibration.addItem("Channel #7")
        cb_coarse_calibration.addItem("Channel #8")
        cb_coarse_calibration.addItem("Channel #9")
        cb_coarse_calibration.addItem("Channel #10")
        cb_coarse_calibration.addItem("Channel #11")
        cb_coarse_calibration.addItem("Channel #12")
        cb_coarse_calibration.addItem("Channel #13")
        cb_coarse_calibration.addItem("Channel #14")
        cb_coarse_calibration.addItem("Channel #15")
        cb_coarse_calibration.addItem("Channel #16")
        
        cb_coarse_calibration.currentIndexChanged.connect(self.coarse_calibration_channel_selectionchange)
        
        
        global cb_fine_calibration
        cb_fine_calibration=QComboBox()
        cb_fine_calibration.addItem("Channel #1")
        cb_fine_calibration.addItem("Channel #2")
        cb_fine_calibration.addItem("Channel #3")
        cb_fine_calibration.addItem("Channel #4")
        cb_fine_calibration.addItem("Channel #5")
        cb_fine_calibration.addItem("Channel #6")
        cb_fine_calibration.addItem("Channel #7")
        cb_fine_calibration.addItem("Channel #8")
        cb_fine_calibration.addItem("Channel #9")
        cb_fine_calibration.addItem("Channel #10")
        cb_fine_calibration.addItem("Channel #11")
        cb_fine_calibration.addItem("Channel #12")
        cb_fine_calibration.addItem("Channel #13")
        cb_fine_calibration.addItem("Channel #14")
        cb_fine_calibration.addItem("Channel #15")
        cb_fine_calibration.addItem("Channel #16")   
        
        cb_fine_calibration.currentIndexChanged.connect(self.fine_calibration_channel_selectionchange)


        combobox_layout.addWidget(cb_coarse_calibration)
        combobox_layout.addWidget(cb_fine_calibration)
        combobox_layout.addWidget(QLabel(""))
        

        main_layout.addLayout(combobox_layout)
        
        
        global table_1
        table_1 =QTableView()
        global table_2
        table_2 =QTableView()
        global table_3
        table_3 =QTableView()
        table_layout.addWidget(table_1)
        table_layout.addWidget(table_2)
        table_layout.addWidget(table_3)
        
        main_layout.addLayout(table_layout)
                
        calibrationTab.setLayout(main_layout)
               
        return calibrationTab


    def onClicked_1(self):
        
        radioButton = self.sender()
        
        if radioButton.isChecked():
            
            self.valueChanged.emit(str(radioButton.calibrationFlowRate))
            print("Calibration flow rate is %s" % (radioButton.calibrationFlowRate))
            time.sleep(1)
            
            l1_start.setText(str(radioButton.startPressure_uint_8_small1))
            l1_stop.setText(str(radioButton.stopPressure_uint_8_small1))
            l1_step.setText(str(radioButton.stepPressure_uint_8_small1))
            l2_start.setText(str(radioButton.startPressure_uint_8_small2))
            l2_stop.setText(str(radioButton.stopPressure_uint_8_small2))
            l2_step.setText(str(radioButton.stepPressure_uint_8_small2))
            l3_start.setText(str(radioButton.startPressure_uint_8_DB))
            l3_stop.setText(str(radioButton.stopPressure_uint_8_DB))
            l3_step.setText(str(radioButton.stepPressure_uint_8_DB))                    
            l4_start.setText(str(radioButton.startPressure_uint_8_PBS))
            l4_stop.setText(str(radioButton.stopPressure_uint_8_PBS))
            l4_step.setText(str(radioButton.stepPressure_uint_8_PBS)) 
            
            self.flow_rate=radioButton.calibrationFlowRate_uint_8
            
            
            
            self.calibration_parameters=(radioButton.startPressure_uint_8_small1,
                                    radioButton.stopPressure_uint_8_small1,
                                    radioButton.stepPressure_uint_8_small1,
                                    radioButton.startPressure_uint_8_small2,
                                    radioButton.stopPressure_uint_8_small2,
                                    radioButton.stepPressure_uint_8_small2,
                                    radioButton.startPressure_uint_8_DB,
                                    radioButton.stopPressure_uint_8_DB,
                                    radioButton.stepPressure_uint_8_DB,
                                    radioButton.startPressure_uint_8_PBS,
                                    radioButton.stopPressure_uint_8_PBS,
                                    radioButton.stepPressure_uint_8_PBS)   
            
            

    def get_calibration_parameters (self):
                        
        self.path=save_directory.text()
         
        self.calibration_parameters=(l1_start.text(),
                                l1_stop.text(),
                                l1_step.text(),
                                l2_start.text(),
                                l2_stop.text(),
                                l2_step.text(),
                                l3_start.text(),
                                l3_stop.text(),
                                l3_step.text(),
                                l4_start.text(),
                                l4_stop.text(),
                                l4_step.text(),)
        data=np.asarray(self.calibration_parameters)
        savetxt(self.path+"/calibration_parameters.csv", data,fmt='%s', header="calibration parameters")
    
    
    def start_auto_calibration (self):
        
        self.path=save_directory.text()
               
         
        self.calibration_parameters=(l1_start.text(),
                                l1_stop.text(),
                                l1_step.text(),
                                l2_start.text(),
                                l2_stop.text(),
                                l2_step.text(),
                                l3_start.text(),
                                l3_stop.text(),
                                l3_step.text(),
                                l4_start.text(),
                                l4_stop.text(),
                                l4_step.text(),)
        
        auto_calibration.calibrate(self.flow_rate, self.path, *self.calibration_parameters)

        
        
    def get_coarse_calibration_data (self):
        self.path=save_directory.text()
        
        self.pressure_coarse_all=np.load(self.path+"/pressure_coarse_all.npy",allow_pickle=True)       
        self.flow_rate_coarse_all=np.load(self.path+"/flow_rate_coarse_all.npy",allow_pickle=True)
        self.valueChanged.emit("Coarse calibration data loaded!")
        time.sleep(1)
        data=[list(self.pressure_coarse_all[0]),list(self.flow_rate_coarse_all[0])]
        for j in range(len(self.pressure_coarse_all[0])):
            data[0][j]=self.pressure_coarse_all[0][j].item()
            data[1][j]=self.flow_rate_coarse_all[0][j].item()       
           
        self.valueChanged.emit("channel #"+str(1)+" pressure and flow rate (coarse calibration) :"+str(data))
        
        self.model = TableModel(data)
        table_1.setModel(self.model)

        
    def get_fine_calibration_data (self):
        self.path=save_directory.text()
        
        self.pressure_fine_all=np.load(self.path+"/pressure_fine_all.npy",allow_pickle=True)       
        self.flow_rate_fine_all=np.load(self.path+"/flow_rate_fine_all.npy",allow_pickle=True) 
        self.valueChanged.emit("Fine calibration data loaded!")
        time.sleep(1)
        
        data=[list(self.pressure_fine_all[0]),list(self.flow_rate_fine_all[0])]
        for j in range(len(self.pressure_fine_all[0])):
            data[0][j]=self.pressure_fine_all[0][j].item()
            data[1][j]=self.flow_rate_fine_all[0][j].item()
           
        self.valueChanged.emit("channel #"+str(1)+" pressure and flow rate (fine calibration) :"+str(data))
        
        self.model = TableModel(data)
        table_2.setModel(self.model)
        
        
        

        
    def get_and_show_set_pressure (self):
        self.path=save_directory.text()
        
        self.set_pressure=np.load(self.path+"/pr_set_channels.npy",allow_pickle=True)       
        self.set_pressure_hex=np.load(self.path+"/pr_set_channels_hex.npy",allow_pickle=True) 
        
        data=[list(self.set_pressure),list(self.set_pressure_hex)]
        
        for j in range(len(self.set_pressure)):
            data[0][j]=self.set_pressure[j].item()
            data[1][j]=self.set_pressure_hex[j].item()
           
        self.valueChanged.emit("set_pressure and set_pressure_hex "+str(data))
        
        self.model = TableModel(data)
        table_3.setModel(self.model)      
        

    def coarse_calibration_channel_selectionchange (self,i):
        
        data=[list(self.pressure_coarse_all[i]),list(self.flow_rate_coarse_all[i])]
        for j in range(len(self.pressure_coarse_all[i])):
            data[0][j]=self.pressure_coarse_all[i][j].item()
            data[1][j]=self.flow_rate_coarse_all[i][j].item()       
           
        self.valueChanged.emit("channel #"+str(i+1)+" pressure and flow rate (coarse calibration  "+str(data))
        
        self.model = TableModel(data)
        table_1.setModel(self.model)
            

    def fine_calibration_channel_selectionchange (self,i):
        
        data=[list(self.pressure_fine_all[i]),list(self.flow_rate_fine_all[i])]
        for j in range(len(self.pressure_fine_all[i])):
            data[0][j]=self.pressure_fine_all[i][j].item()
            data[1][j]=self.flow_rate_fine_all[i][j].item()
           
        self.valueChanged.emit("channel #"+str(i+1)+" pressure and flow rate (fine calibration )"+str(data))
        
        self.model = TableModel(data)
        table_2.setModel(self.model)
        
        
    def calibration_verificationTabUI(self):
        """Create the Flow rate verification page UI."""
        calibration_verificationTab = QWidget()
        
        main_layout=QVBoxLayout()
        sub_layout_1=QHBoxLayout()
       
        
       
        
     
        # calibration_res_layout=QHBoxLayout()
        # combobox_layout=QHBoxLayout()
        # table_layout=QHBoxLayout()
        
        flow_rate_verification_btn = QPushButton('Flow rate verification')
        flow_rate_verification_btn.clicked.connect(self.calibration_verification)  
        main_layout.addWidget(flow_rate_verification_btn)
        
        injection_volume_text_1=QLabel("Injection volume (ul)") 
        
        #injection_volume_text.setGeometry(0, 10, 10, 10)
        #injection_volume_text.setWordWrap(True)
        sub_layout_1.addWidget(injection_volume_text_1)
        
        global injection_volume
        injection_volume=QLineEdit()
        injection_volume.setText('800')
        sub_layout_1.addWidget(injection_volume)
        
        injection_volume_text_2=QLabel("(for PBS, this value will be double)")
        
        sub_layout_1.addWidget(injection_volume_text_2)
        
        main_layout.addLayout(sub_layout_1)
       
        
        flow_rate_convert_btn=QPushButton('Convert flow rate and show injection time')
        flow_rate_convert_btn.clicked.connect(self.flow_rate_conversion)
        main_layout.addWidget(flow_rate_convert_btn)
        
        global table_4
        table_4 =QTableView()
       

        main_layout.addWidget(table_4)
        initial_data=[[0,0,0,0],[0,0,0,0]]
        model = TableModel(initial_data)
        table_4.setModel(model)
        
        main_layout.setSizeConstraint(QLayout.SetMinAndMaxSize)
        
        calibration_verificationTab.setLayout(main_layout)
        return calibration_verificationTab
        
    def calibration_verification (self):
        self.path=save_directory.text()
        ave_flow_rate=cv_DB.calibrate_verification(self.path)
        self.valueChanged.emit(str(ave_flow_rate))
        
    def flow_rate_conversion (self):
        
        self.path=save_directory.text()
        iv=injection_volume.text()
        ave_flow_rate,injection_time=frcc.flow_rate_conversion(self.path, iv)
        
        data=[list(ave_flow_rate),list(injection_time)]
        
        for j in range(len(ave_flow_rate)):
            data[0][j]=ave_flow_rate[j].item()
            data[1][j]=injection_time[j].item()
            
        self.model = TableModel(data)
        table_4.setModel(self.model)
        
        self.valueChanged.emit("flow rate and injection time shown in the table above!")
        
        
        
    def run_single_channelTabUI(self):
        """Create the Run single channel page UI."""
        run_single_channelTab = QWidget()
        
        main_layout=QVBoxLayout()
        sub_layout_1=QHBoxLayout()
        radio_btn_layout=QHBoxLayout()
        single_channel_btn_layout=QGridLayout()
        
        self.path=save_directory.text()
        
        injection_time_text_1=QLabel("Injection time (s)")     
        sub_layout_1.addWidget(injection_time_text_1)
        
        global injection_time
        injection_time=QLineEdit()
        injection_time.setText('10')
        sub_layout_1.addWidget(injection_time)

        
        main_layout.addLayout(sub_layout_1)
        
        radiobutton = QRadioButton("maximum flow rate")
        radiobutton.setChecked(True)
        radiobutton.set_pressure = [127]*16
        radiobutton.toggled.connect(self.onClicked_2)
        radio_btn_layout.addWidget(radiobutton)
        
        radiobutton = QRadioButton("calibration flow rate")
        radiobutton.set_pressure = np.load(self.path+'/pr_set_channels.npy',allow_pickle=True)        
        radiobutton.toggled.connect(self.onClicked_2)
        radio_btn_layout.addWidget(radiobutton)
        
        main_layout.addLayout(radio_btn_layout)
        
        channel_1_btn=QPushButton("Channel_1")
        channel_1_btn.clicked.connect(self.run_single_channel)
        channel_1_btn.setCheckable(True)
        channel_2_btn=QPushButton("Channel_2")
        channel_2_btn.clicked.connect(self.run_single_channel)
        channel_2_btn.setCheckable(True)
        channel_3_btn=QPushButton("Channel_3")
        channel_3_btn.clicked.connect(self.run_single_channel)
        channel_3_btn.setCheckable(True)
        channel_4_btn=QPushButton("Channel_4")
        channel_4_btn.clicked.connect(self.run_single_channel)
        channel_4_btn.setCheckable(True)
        channel_5_btn=QPushButton("Channel_5")
        channel_5_btn.clicked.connect(self.run_single_channel)
        channel_5_btn.setCheckable(True)
        channel_6_btn=QPushButton("Channel_6")
        channel_6_btn.clicked.connect(self.run_single_channel)
        channel_6_btn.setCheckable(True)
        channel_7_btn=QPushButton("Channel_7")
        channel_7_btn.clicked.connect(self.run_single_channel)
        channel_7_btn.setCheckable(True)
        channel_8_btn=QPushButton("Channel_8")
        channel_8_btn.clicked.connect(self.run_single_channel)
        channel_8_btn.setCheckable(True)
        channel_9_btn=QPushButton("Channel_9")
        channel_9_btn.clicked.connect(self.run_single_channel)
        channel_9_btn.setCheckable(True)
        channel_10_btn=QPushButton("Channel_10")
        channel_10_btn.clicked.connect(self.run_single_channel)
        channel_10_btn.setCheckable(True)
        channel_11_btn=QPushButton("Channel_11")
        channel_11_btn.clicked.connect(self.run_single_channel)
        channel_11_btn.setCheckable(True)
        channel_12_btn=QPushButton("Channel_12")
        channel_12_btn.clicked.connect(self.run_single_channel)
        channel_12_btn.setCheckable(True)
        channel_13_btn=QPushButton("Channel_13")
        channel_13_btn.clicked.connect(self.run_single_channel)
        channel_13_btn.setCheckable(True)
        channel_14_btn=QPushButton("Channel_14")
        channel_14_btn.clicked.connect(self.run_single_channel)
        channel_14_btn.setCheckable(True)
        channel_15_btn=QPushButton("Channel_15")
        channel_15_btn.clicked.connect(self.run_single_channel)
        channel_15_btn.setCheckable(True)
        channel_16_btn=QPushButton("Channel_16")
        channel_16_btn.clicked.connect(self.run_single_channel)
        channel_16_btn.setCheckable(True)        
        
        single_channel_btn_layout.addWidget(channel_1_btn, 0, 0)
        single_channel_btn_layout.addWidget(channel_2_btn, 0, 1)
        single_channel_btn_layout.addWidget(channel_3_btn, 0, 2)
        single_channel_btn_layout.addWidget(channel_4_btn, 0, 3)
        single_channel_btn_layout.addWidget(channel_5_btn, 0, 4)
        single_channel_btn_layout.addWidget(channel_6_btn, 0, 5)
        single_channel_btn_layout.addWidget(channel_7_btn, 0, 6)
        single_channel_btn_layout.addWidget(channel_8_btn, 0, 7)
        single_channel_btn_layout.addWidget(channel_9_btn, 1, 0)
        single_channel_btn_layout.addWidget(channel_10_btn, 1, 1)
        single_channel_btn_layout.addWidget(channel_11_btn, 1, 2)
        single_channel_btn_layout.addWidget(channel_12_btn, 1, 3)
        single_channel_btn_layout.addWidget(channel_13_btn, 1, 4)
        single_channel_btn_layout.addWidget(channel_14_btn, 1, 5)
        single_channel_btn_layout.addWidget(channel_15_btn, 1, 6)
        single_channel_btn_layout.addWidget(channel_16_btn, 1, 7)
        
        
        main_layout.addLayout(single_channel_btn_layout)
        
        
        run_single_channelTab.setLayout(main_layout)
        return run_single_channelTab
    
      
    def onClicked_2 (self):
        
        radioButton = self.sender()
        
        if radioButton.isChecked():
         
            self.set_pressure=radioButton.set_pressure
        
        
            
    def run_single_channel (self):
        it=int(injection_time.text())
        source=self.sender()
        button_text=source.text()
        temp=re.split('(\d+)',button_text)
        temp=int(temp[-2])

        run_individual_channel.run_inject(it,self.set_pressure,temp)

        source.setChecked(False)
    
            

            
if __name__ == "__main__":
    
    if not QApplication.instance():
        app = QApplication(sys.argv)
    else:
        app = QApplication.instance() 
        
    app.setStyle("Fusion")
    palette = QPalette()
    
    palette.setColor(QPalette.Window, QColor(53, 53, 53))
    palette.setColor(QPalette.WindowText, Qt.white)
    palette.setColor(QPalette.Base, QColor(25, 25, 25))
    palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
    palette.setColor(QPalette.ToolTipBase, Qt.black)
    palette.setColor(QPalette.ToolTipText, Qt.white)
    palette.setColor(QPalette.Text, Qt.white)
    palette.setColor(QPalette.Button, QColor(53, 53, 53))
    palette.setColor(QPalette.ButtonText, Qt.white)
    palette.setColor(QPalette.BrightText, Qt.red)
    palette.setColor(QPalette.Link, QColor(42, 130, 218))
    palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
    palette.setColor(QPalette.HighlightedText, Qt.black)
    app.setPalette(palette)

    window = Window()
    window.show()
    
    sys.exit(app.exec_())