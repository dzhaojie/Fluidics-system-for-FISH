# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import serial
import struct
import time
from scipy import optimize
import numpy as np

t1=time.perf_counter()

def fun(x, a, b):
    return a*x+b

PATH='/Users/lzdeng/Documents/Automatic fluidics system/flow rate calibration sheets/20210428/target flow rate 145'
FLOW_RATE=145
MAX_FLOW_RATE_SCANED=min(252,FLOW_RATE+20)
PR_NUMBER=120
FLOW_RATE_SENSOR_NUMBER=121
OPEN=123
CLOSE=124
STATUS_REQUEST=125
VALVE_NUMBER=['23','22','21','20','19','18','17','16','108','109','110','111','104','105','106','107']
RESERVOIR_SIZE=['samll','samll','samll','samll','samll','samll','samll','samll','samll','samll','samll','samll','large','large','samll','samll']
SELECTED_CHANNELS=np.array([1,1,1,1,0,0,0,0,0,0,0,0,1,1,0,0])
#VALVE_NUMBER=['23','22','21','104','105']
#RESERVOIR_SIZE=['samll','samll','samll','large','large']
NUMBER_OF_CHANNELS=16


pr_set_channels=[]
pressure_coarse_all=[]
pressure_fine_all=[]
flow_rate_coarse_all=[]
flow_rate_fine_all=[]

ser_ESP32=serial.Serial('/dev/cu.SLAB_USBtoUART', baudrate=115200, timeout=10)
BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
ser_ESP32.write(BytetoWrite)
time.sleep(1)
s_pr_status=ser_ESP32.read(4)


for i in range (NUMBER_OF_CHANNELS):
    
    print (i+1)
    
    if RESERVOIR_SIZE[i]=='samll':
    
        pressure_coarse=[] # for coarse step calibration    
        flow_rate_coarse=[]    
        pressure_measure_coarse=[]
          
        
        for j in range (40,150,5):
    
            pr_set=j
            pressure_coarse.append(j)
            
            BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(pr_set))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(PR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            pressure_measure_coarse.append(s_pr_status[2])
            print(s_pr_status)
    
            BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(OPEN))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_valve_status=ser_ESP32.read(4)
            time.sleep(3)
    
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(FLOW_RATE_SENSOR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_fr_sensor_status=ser_ESP32.read(4)
            flow_rate_coarse.append(s_fr_sensor_status[2])
            
            if s_fr_sensor_status[2]>=MAX_FLOW_RATE_SCANED:
                break
            
        BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(CLOSE))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_valve_status=ser_ESP32.read(4)
                
        BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
        ser_ESP32.write(BytetoWrite)
        time.sleep(1)
        s_pr_status=ser_ESP32.read(4)
        
        
        time.sleep(8)
        
        
        flow_rate_coarse=np.array(flow_rate_coarse)
        pressure_coarse=np.array(pressure_coarse)
        flow_rate_coarse_all.append(flow_rate_coarse)
        pressure_coarse_all.append(pressure_coarse)   
        
    else:
        
        pressure_coarse=[] # for coarse step calibration    
        flow_rate_coarse=[]    
        pressure_measure_coarse=[]
          
        
        for j in range (40,127,1):
    
            pr_set=j
            pressure_coarse.append(j)
            
            BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(pr_set))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(PR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            pressure_measure_coarse.append(s_pr_status[2])
            print(s_pr_status)
    
            BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(OPEN))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_valve_status=ser_ESP32.read(4)
            time.sleep(3)
    
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(FLOW_RATE_SENSOR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_fr_sensor_status=ser_ESP32.read(4)
            flow_rate_coarse.append(s_fr_sensor_status[2])
            
            if s_fr_sensor_status[2]>=MAX_FLOW_RATE_SCANED:
                break
            
        BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(CLOSE))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_valve_status=ser_ESP32.read(4)
                
        BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
        ser_ESP32.write(BytetoWrite)
        time.sleep(1)
        s_pr_status=ser_ESP32.read(4)
        
        
        time.sleep(8)
        
        
        flow_rate_coarse=np.array(flow_rate_coarse)
        pressure_coarse=np.array(pressure_coarse)
        flow_rate_coarse_all.append(flow_rate_coarse)
        pressure_coarse_all.append(pressure_coarse)   
    
        
action=input("Ready to start fine calibration. Proceed (1/0)?")

if int(action)==1:
    
    for i in range (NUMBER_OF_CHANNELS):
        
        print (i+1)
        
        if RESERVOIR_SIZE[i]=='samll': 

            pressure_fine=[] # for fine step calibration    
            flow_rate_fine=[]    
            pressure_measure_fine=[]
        
            index=np.where( np.logical_and(flow_rate_coarse_all[i]>=max((FLOW_RATE-10),130), flow_rate_coarse_all[i]<=(FLOW_RATE+10)))
            pressure_roi=pressure_coarse_all[i][index]         
            a=pressure_roi[0]
            b=pressure_roi[len(pressure_roi)-1]+1
        
            
            while (b-a)<11: # minimum number of calibration points set as 11
                a=a-1
                b=b+1    
        
        
            for k in range (a,b,1):
                
                pr_set=k
                pressure_fine.append(k)
                
                BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(pr_set))
                ser_ESP32.write(BytetoWrite)
                time.sleep(0.5)
                s_pr_status=ser_ESP32.read(4)
                
                BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(PR_NUMBER))
                ser_ESP32.write(BytetoWrite)
                time.sleep(0.5)
                s_pr_status=ser_ESP32.read(4)
                pressure_measure_fine.append(s_pr_status[2])
                print(s_pr_status)
        
                BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(OPEN))
                ser_ESP32.write(BytetoWrite)
                time.sleep(0.5)
                s_valve_status=ser_ESP32.read(4) 
                if FLOW_RATE<190:
                    time.sleep(3)
                else:
                    time.sleep(1)
        
                BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(FLOW_RATE_SENSOR_NUMBER))
                ser_ESP32.write(BytetoWrite)
                time.sleep(0.5)
                s_fr_sensor_status=ser_ESP32.read(4)
                flow_rate_fine.append(s_fr_sensor_status[2])
                
        
            BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(CLOSE))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_valve_status=ser_ESP32.read(4)
                    
            BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
            ser_ESP32.write(BytetoWrite)
            time.sleep(1)
            s_pr_status=ser_ESP32.read(4)
            
            
            flow_rate_fine=np.array(flow_rate_fine)
            pressure_fine=np.array(pressure_fine)                
            
            
            pressure_fine_all.append(pressure_fine)
            flow_rate_fine_all.append(flow_rate_fine)
            
            
            y=flow_rate_fine
            x=pressure_fine
        
            y_params, y_params_covariance = optimize.curve_fit(fun, x, y, p0=[2, 2],maxfev=5000)
            pr_set_temp=(FLOW_RATE-y_params[1])/y_params[0]
            pr_set_channels.append(np.round(pr_set_temp))

            
        else:
        
            flow_rate_fine_index=np.where(np.logical_and(flow_rate_coarse_all[i]>=FLOW_RATE-3 ,flow_rate_coarse_all[i]<=FLOW_RATE+3))
            flow_rate_fine=flow_rate_coarse_all[i][flow_rate_fine_index]
            pressure_fine=pressure_coarse_all[i][flow_rate_fine_index]
            

            y=flow_rate_fine
            x=pressure_fine
        
            y_params, y_params_covariance = optimize.curve_fit(fun, x, y, p0=[2, 2],maxfev=5000)
            pr_set_temp=(FLOW_RATE-y_params[1])/y_params[0]
            pr_set_channels.append(np.round(pr_set_temp))            
            
            
            
else:
    print ("Calibration procesure not sucessful")
        
pr_set_channels=np.array(pr_set_channels)
pr_set_channels=pr_set_channels.astype(int)
vhex = np.vectorize(hex)
pr_set_channels_hex=vhex(pr_set_channels)


pressure_coarse_all_temp=pressure_coarse_all
pressure_fine_all_temp=pressure_fine_all
flow_rate_coarse_all_temp=flow_rate_coarse_all
flow_rate_fine_all_temp=flow_rate_fine_all
pr_set_channels_temp=pr_set_channelsp
pr_set_channels_hex_temp=pr_set_channels_hex


pressure_coarse_all=np.empty(16,dtype=object)



for i in (16):
    if SELECTED_CHANNELS==1:
        
        


np.save(PATH+'/pressure_coarse_all.npy',pressure_coarse_all)
np.save(PATH+'/pressure_fine_all.npy',pressure_fine_all)
np.save(PATH+'/flow_rate_coarse_all.npy',flow_rate_coarse_all)
np.save(PATH+'/flow_rate_fine_all.npy',flow_rate_fine_all)
np.save(PATH+'/pr_set_channels.npy',pr_set_channels)
np.save(PATH+'/pr_set_channels_hex.npy',pr_set_channels_hex)




ser_ESP32.close()
t2=time.perf_counter()
print((t2-t1)/60)



