#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 13:40:59 2021

@author: lzdeng
"""

import serial
import struct
import time
import numpy as np


PATH='/Users/lzdeng/Documents/Automatic fluidics system/flow rate calibration sheets/20210408/target flow rate 145'
PR_NUMBER=120
FLOW_RATE_SENSOR_NUMBER=121
OPEN=123
CLOSE=124
STATUS_REQUEST=125
INJECTION_TIME=30
#VALVE_NUMBER=['23','22','21','20','19','18','17','16','108','109','110','111','104','105','106','107']
VALVE_NUMBER=['105']
SET_PRESURE=np.load(PATH+'/pr_set_channels.npy')
NUMBER_OF_CHANNELS=1


flow_rate_measured=np.empty(16, dtype=np.object)
for i in range(flow_rate_measured.shape[0]):
    flow_rate_measured[i]=[]

pressure_measured=np.empty(16, dtype=np.object)
for i in range(pressure_measured.shape[0]):
    pressure_measured[i]=[]
    
time_elapsed=[]

    
ser_ESP32=serial.Serial('/dev/cu.SLAB_USBtoUART', baudrate=115200, timeout=10)
BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
ser_ESP32.write(BytetoWrite)
time.sleep(0.5)
s_pr_status=ser_ESP32.read(4)


for i in range (NUMBER_OF_CHANNELS):
    
    #action=input("Ready to start injection for channel #"+str(i)+". Proceed (1/0)?")
    action=1

    if int(action)==1:
        
        SET_PRESURE[i]=120
        
        BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(SET_PRESURE[i]))
        ser_ESP32.write(BytetoWrite)
        time.sleep(3)
        s_pr_status=ser_ESP32.read(4)
        
        BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(OPEN))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_valve_status=ser_ESP32.read(4)
        

        Te=0
        T1=time.perf_counter()
        
        while (Te<INJECTION_TIME):
            
            time.sleep(3)

            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(FLOW_RATE_SENSOR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_fr_sensor_status=ser_ESP32.read(4)
            flow_rate_measured[i].append(s_fr_sensor_status[2]) 

            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(PR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            pressure_measured[i].append(s_pr_status[2])
            
            T2=time.perf_counter()
            Te=T2-T1
            
            
        time_elapsed.append(Te)
            
            
        BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(CLOSE))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_valve_status=ser_ESP32.read(4)  
        time.sleep(10)
        
        
    else:
        print ("Injection from channel #"+str(i)+" failed")
        
    
BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
ser_ESP32.write(BytetoWrite)
time.sleep(1)
s_pr_status=ser_ESP32.read(4)




# np.save(PATH+'/flow_rate_measured.npy',flow_rate_measured)
# np.save(PATH+'/pressure_measured.npy',pressure_measured)
# np.save(PATH+'/time_elapsed.npy',time_elapsed)

ave_flow_rate_measured=np.empty(NUMBER_OF_CHANNELS)
for i in range (NUMBER_OF_CHANNELS):
    ave_flow_rate_measured[i]=np.mean(flow_rate_measured[i])
    
ser_ESP32.close()