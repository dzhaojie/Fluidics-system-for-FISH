#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 13:40:59 2021

@author: lzdeng
"""

import serial
import struct
import time
import numpy as np


PR_NUMBER=120
FLOW_RATE_SENSOR_NUMBER=121
OPEN=123
CLOSE=124
STATUS_REQUEST=125
INJECTION_TIME=35



VALVE_NUMBER=['23','22','21','20','19','18','17','16','108','109','110','111','104','105','106','107']

channel_number=5  #valve to close


    
ser_ESP32=serial.Serial('/dev/cu.usbserial-14320', baudrate=115200, timeout=10)
BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
ser_ESP32.write(BytetoWrite)
time.sleep(0.5)
s_pr_status=ser_ESP32.read(4)

    
    


BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[channel_number-1]),int(CLOSE))
ser_ESP32.write(BytetoWrite)
time.sleep(0.5)
s_valve_status=ser_ESP32.read(4)

time.sleep(5)

ser_ESP32.close()

    



    





