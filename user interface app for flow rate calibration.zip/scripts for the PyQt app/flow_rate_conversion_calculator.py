#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  5 12:20:43 2021

@author: lzdeng
"""


import time
from scipy import optimize
import numpy as np



def flow_rate_conversion (path,injection_volume):
    
    def fun(x, a, b):
        return a*x+b
    
    
    PATH=path
    NUMBER_OF_CHANNELS=16
    
    ### flow rate sensor calibration data for DI water ###
    #calibration_flow_rate_uint8=np.array([128,135,144,148,205])
    #calibration_flow_rate=np.array([17.978,69.598,124.987,182.915,669.199])
    
    ### flow rate sensor calibration data for 1X PBS ###
    calibration_flow_rate_uint8=np.array([128, 133.129, 140.36, 151.36, 182.8, 217.87, 248.75])
    calibration_flow_rate=np.array([5.99 ,41.92, 99.73, 209.58, 532.93, 898.20, 1272.22])
    
    
    
    
    x=calibration_flow_rate_uint8
    y=calibration_flow_rate
    
    y_params, y_params_covariance = optimize.curve_fit(fun, x, y, p0=[2, 2],maxfev=5000)
    
    
    flow_rate_measured_uint8=np.load(PATH+'/flow_rate_measured.npy',allow_pickle=True)
    
    ave_flow_rate_measured=np.empty(NUMBER_OF_CHANNELS,dtype=object)
    flow_rate_measured=np.empty(NUMBER_OF_CHANNELS,dtype=object)
    
    for i in range (NUMBER_OF_CHANNELS):
        flow_rate_measured[i]=fun(np.array(flow_rate_measured_uint8[i]),y_params[0],y_params[1])
    
    for i in range (NUMBER_OF_CHANNELS):
        flow_rate_measured_temp=flow_rate_measured[i][4:]
        flow_rate_measured_temp=flow_rate_measured_temp[flow_rate_measured_temp>0]
        ave_flow_rate_measured[i]=np.mean(flow_rate_measured_temp)
    
    
    WaitTime=int(injection_volume)*60/ave_flow_rate_measured
    #WaitTime[12]=WaitTime[12] ###inject 3X 800ul displacement buffer
    WaitTime[13]=2*WaitTime[13]
    
    np.save(PATH+'/WaitTime.npy',WaitTime)
    np.save(PATH+'/ave_flow_rate_measured.npy',ave_flow_rate_measured)
    
    return ave_flow_rate_measured, WaitTime
    
