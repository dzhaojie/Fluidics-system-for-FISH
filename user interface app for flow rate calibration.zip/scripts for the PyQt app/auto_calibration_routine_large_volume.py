# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import serial
import struct
import time
from scipy import optimize
import numpy as np

t1=time.perf_counter()

def fun(x, a, b):
    return a*x+b

PATH='/Users/lzdeng/Documents/Automatic fluidics system/flow rate calibration sheets/20210401/target flow rate 145'
FLOW_RATE=145
MAX_FLOW_RATE_SCANED=min(252,FLOW_RATE+20)
PR_NUMBER=120
FLOW_RATE_SENSOR_NUMBER=121
OPEN=123
CLOSE=124
STATUS_REQUEST=125
VALVE_NUMBER=['23','22','21','20','19','18','17','16','108','109','110','111','104','105','106','107']
NUMBER_OF_CHANNELS=1


pr_set_channels=[]
pressure=[]
pressure_all=[]
flow_rate=[]
flow_rate_all=[]

ser_ESP32=serial.Serial('/dev/cu.SLAB_USBtoUART', baudrate=115200, timeout=10)
BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
ser_ESP32.write(BytetoWrite)
time.sleep(1)
s_pr_status=ser_ESP32.read(4)


for i in range (NUMBER_OF_CHANNELS):
    
    print (i+1)
    
    pressure=[] # for coarse step calibration    
    flow_rate=[]    
    pressure_measure=[]
      
    
    for j in range (40,127,1):

        pr_set=j
        pressure.append(j)
        
        BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(pr_set))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_pr_status=ser_ESP32.read(4)
        
        BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(PR_NUMBER))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_pr_status=ser_ESP32.read(4)
        pressure_measure.append(s_pr_status[2])
        print(s_pr_status)

        BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(OPEN))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_valve_status=ser_ESP32.read(4)
        time.sleep(3)

        BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(FLOW_RATE_SENSOR_NUMBER))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_fr_sensor_status=ser_ESP32.read(4)
        flow_rate.append(s_fr_sensor_status[2])
        
        if s_fr_sensor_status[2]>=MAX_FLOW_RATE_SCANED:
            break
        
    BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(CLOSE))
    ser_ESP32.write(BytetoWrite)
    time.sleep(0.5)
    s_valve_status=ser_ESP32.read(4)
            
    BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
    ser_ESP32.write(BytetoWrite)
    time.sleep(1)
    s_pr_status=ser_ESP32.read(4)
    
    
    time.sleep(8)
    
    
    flow_rate=np.array(flow_rate)
    pressure=np.array(pressure)
    flow_rate_all.append(flow_rate)
    pressure_all.append(pressure)    

    
    flow_rate_cal_index=np.where(np.logical_and(flow_rate>=FLOW_RATE-3 ,flow_rate<=FLOW_RATE+3))
    flow_rate_cal=flow_rate[flow_rate_cal_index]
    pressure_cal=pressure[flow_rate_cal_index]
    
        
    y=flow_rate_cal
    x=pressure_cal
    
    y_params, y_params_covariance = optimize.curve_fit(fun, x, y, p0=[2, 2],maxfev=5000)
    pr_set_temp=(FLOW_RATE-y_params[1])/y_params[0]
    pr_set_channels.append(np.round(pr_set_temp))

        
pr_set_channels=np.array(pr_set_channels)
pr_set_channels=pr_set_channels.astype(int)
vhex = np.vectorize(hex)
pr_set_channels_hex=vhex(pr_set_channels)


np.save(PATH+'/pressure_all_large_volume.npy',pressure_all)
np.save(PATH+'/flow_rate_all_large_volume.npy',flow_rate_all)
np.save(PATH+'/pr_set_channels_large_volume.npy',pr_set_channels)
np.save(PATH+'/pr_set_channels_hex_large_volume.npy',pr_set_channels_hex)




ser_ESP32.close()
t2=time.perf_counter()
print((t2-t1)/60)



