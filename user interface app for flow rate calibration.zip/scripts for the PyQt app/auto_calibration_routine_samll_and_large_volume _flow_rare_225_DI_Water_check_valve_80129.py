# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import serial
import struct
import time
from scipy import optimize
import numpy as np

t1=time.perf_counter()

def fun(x, a, b):
    return a*x+b

PATH='/Users/lzdeng/Documents/Automatic fluidics system/flow rate calibration sheets/20210629/target flow rate 225'
FLOW_RATE=225
MAX_FLOW_RATE_SCANED=min(252,FLOW_RATE+20)
PR_NUMBER=120
FLOW_RATE_SENSOR_NUMBER=121
OPEN=123
CLOSE=124
STATUS_REQUEST=125
VALVE_NUMBER=['23','22','21','20','19','18','17','16','108','109','110','111','104','105','106','107']
RESERVOIR_SIZE=['samll','samll','samll','samll','samll','samll','samll','samll','samll','samll','samll','samll','large','large','samll','samll']
#VALVE_NUMBER=['23','22','21','20','104','105']
#RESERVOIR_SIZE=['samll','samll','samll','samll','large','large']
NUMBER_OF_CHANNELS=16


pr_set_channels=[]
pressure_coarse_all=[]
pressure_fine_all=[]
flow_rate_coarse_all=[]
flow_rate_fine_all=[]

ser_ESP32=serial.Serial('/dev/cu.SLAB_USBtoUART', baudrate=115200, timeout=10)
BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
ser_ESP32.write(BytetoWrite)
time.sleep(1)
s_pr_status=ser_ESP32.read(4)


for i in range (NUMBER_OF_CHANNELS):
    
    print (i+1)
    
    if RESERVOIR_SIZE[i]=='samll' and i != 14:
    
        pressure_coarse=[] # for coarse step calibration    
        flow_rate_coarse=[]    
        pressure_measure_coarse=[]
          
        
        for j in range (90,130,2):
    
            pr_set=j
            pressure_coarse.append(j)
            
            BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(pr_set))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(PR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            pressure_measure_coarse.append(s_pr_status[2])
            print(s_pr_status)
    
            BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(OPEN))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_valve_status=ser_ESP32.read(4)
            time.sleep(1)
    
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(FLOW_RATE_SENSOR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_fr_sensor_status=ser_ESP32.read(4)
            flow_rate_coarse.append(s_fr_sensor_status[2])
            
            if s_fr_sensor_status[2]>=MAX_FLOW_RATE_SCANED:
                break
            
        BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(CLOSE))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_valve_status=ser_ESP32.read(4)
                
        BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
        ser_ESP32.write(BytetoWrite)
        time.sleep(1)
        s_pr_status=ser_ESP32.read(4)
        
        
        time.sleep(10)
        
        
        flow_rate_coarse=np.array(flow_rate_coarse)
        pressure_coarse=np.array(pressure_coarse)
        flow_rate_coarse_all.append(flow_rate_coarse)
        pressure_coarse_all.append(pressure_coarse)   
        
    elif RESERVOIR_SIZE[i]=='samll':
        
        pressure_coarse=[] # for coarse step calibration    
        flow_rate_coarse=[]    
        pressure_measure_coarse=[]        
        
        for j in range (130,170,2):
    
            pr_set=j
            pressure_coarse.append(j)
            
            BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(pr_set))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(PR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            pressure_measure_coarse.append(s_pr_status[2])
            print(s_pr_status)
    
            BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(OPEN))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_valve_status=ser_ESP32.read(4)
            time.sleep(1)
    
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(FLOW_RATE_SENSOR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_fr_sensor_status=ser_ESP32.read(4)
            flow_rate_coarse.append(s_fr_sensor_status[2])
            
            if s_fr_sensor_status[2]>=MAX_FLOW_RATE_SCANED:
                break
            
        BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(CLOSE))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_valve_status=ser_ESP32.read(4)
                
        BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
        ser_ESP32.write(BytetoWrite)
        time.sleep(1)
        s_pr_status=ser_ESP32.read(4)
        
        
        time.sleep(10)
        
        
        flow_rate_coarse=np.array(flow_rate_coarse)
        pressure_coarse=np.array(pressure_coarse)
        flow_rate_coarse_all.append(flow_rate_coarse)
        pressure_coarse_all.append(pressure_coarse)   
        
        
    else:
        
        pressure_coarse=[] # for coarse step calibration    
        flow_rate_coarse=[]    
        pressure_measure_coarse=[]
          
        
        for j in range (90,130,1):
    
            pr_set=j
            pressure_coarse.append(j)
            
            BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(pr_set))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(PR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_pr_status=ser_ESP32.read(4)
            pressure_measure_coarse.append(s_pr_status[2])
            print(s_pr_status)
    
            BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(OPEN))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_valve_status=ser_ESP32.read(4)
            time.sleep(3)
    
            BytetoWrite=struct.pack('>2B',int(STATUS_REQUEST),int(FLOW_RATE_SENSOR_NUMBER))
            ser_ESP32.write(BytetoWrite)
            time.sleep(0.5)
            s_fr_sensor_status=ser_ESP32.read(4)
            flow_rate_coarse.append(s_fr_sensor_status[2])
            
            if s_fr_sensor_status[2]>=MAX_FLOW_RATE_SCANED:
                break
            
        BytetoWrite=struct.pack('>2B',int(VALVE_NUMBER[i]),int(CLOSE))
        ser_ESP32.write(BytetoWrite)
        time.sleep(0.5)
        s_valve_status=ser_ESP32.read(4)
                
        BytetoWrite=struct.pack('>2B',int(PR_NUMBER),int(0))
        ser_ESP32.write(BytetoWrite)
        time.sleep(1)
        s_pr_status=ser_ESP32.read(4)
        
        
        time.sleep(10)
        
        
        flow_rate_coarse=np.array(flow_rate_coarse)
        pressure_coarse=np.array(pressure_coarse)
        flow_rate_coarse_all.append(flow_rate_coarse)
        pressure_coarse_all.append(pressure_coarse)   
    
        


    
for i in range (NUMBER_OF_CHANNELS):
    

    
    if (i==12 or i==13):

        flow_rate_fine_index=np.where(np.logical_and(flow_rate_coarse_all[i]>=FLOW_RATE-10 ,flow_rate_coarse_all[i]<=FLOW_RATE+10))
                
        flow_rate_fine=flow_rate_coarse_all[i][flow_rate_fine_index]
        pressure_fine=pressure_coarse_all[i][flow_rate_fine_index]
                    
        pressure_fine_all.append(pressure_fine)
        flow_rate_fine_all.append(flow_rate_fine)
    
        y=flow_rate_fine[np.where(np.logical_and(flow_rate_fine>np.min(flow_rate_fine),flow_rate_fine<252))]
        x=pressure_fine[np.where(np.logical_and(flow_rate_fine>np.min(flow_rate_fine),flow_rate_fine<252))]
        
        if len(y)<2:
            y=flow_rate_fine[np.where(flow_rate_fine<252)]
            x=pressure_fine[np.where(flow_rate_fine<252)]
        if len(y)<2:
            y=flow_rate_fine[:2]
            x=pressure_fine[:2]            
    
        y_params, y_params_covariance = optimize.curve_fit(fun, x, y, p0=[2, 2],maxfev=5000)
        pr_set_temp=(FLOW_RATE-y_params[1])/y_params[0]
        pr_set_channels.append(np.round(pr_set_temp))            
    
    else:
        
    
        flow_rate_fine=flow_rate_coarse_all[i]
        pressure_fine=pressure_coarse_all[i]
     
                        
        pressure_fine_all.append(pressure_fine)
        flow_rate_fine_all.append(flow_rate_fine)
    
        y=flow_rate_fine
        x=pressure_fine
            
    
        y_params, y_params_covariance = optimize.curve_fit(fun, x, y, p0=[2, 2],maxfev=5000)
        pr_set_temp=(FLOW_RATE-y_params[1])/y_params[0]
        pr_set_channels.append(np.round(pr_set_temp))            
            
    
        

        
pr_set_channels=np.array(pr_set_channels)
pr_set_channels=pr_set_channels.astype(int)
vhex = np.vectorize(hex)
pr_set_channels_hex=vhex(pr_set_channels)

pressure_coarse_all=np.array(pressure_coarse_all,dtype=object)
pressure_fine_all=np.array(pressure_fine_all,dtype=object)
flow_rate_coarse_all=np.array(flow_rate_coarse_all,dtype=object)
flow_rate_fine_all=np.array(flow_rate_fine_all,dtype=object)
pr_set_channels=np.array(pr_set_channels)
pr_set_channels_hex=np.array(pr_set_channels_hex)





np.save(PATH+'/pressure_coarse_all.npy',pressure_coarse_all,allow_pickle=True)
np.save(PATH+'/pressure_fine_all.npy',pressure_fine_all,allow_pickle=True)
np.save(PATH+'/flow_rate_coarse_all.npy',flow_rate_coarse_all,allow_pickle=True)
np.save(PATH+'/flow_rate_fine_all.npy',flow_rate_fine_all,allow_pickle=True)
np.save(PATH+'/pr_set_channels.npy',pr_set_channels,allow_pickle=True)
np.save(PATH+'/pr_set_channels_hex.npy',pr_set_channels_hex,allow_pickle=True)




ser_ESP32.close()
t2=time.perf_counter()
print((t2-t1)/60)



