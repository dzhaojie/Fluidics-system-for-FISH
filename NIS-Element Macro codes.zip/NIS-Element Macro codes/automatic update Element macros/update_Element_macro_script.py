#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 11:58:50 2021

@author: lzdeng
uncomment/comment line17 and uncomment/comment line18 to choose btween select all the channels or some of the channels
uncomment/comment line27 and uncomment/comment line28 to choose btween FISH experiment or just testing the system

"""
import numpy as np


WASH=0;
VALVE_NUMBER=['23','22','21','20','19','18','17','16','108','109','110','111','104','105','106','107']
replacements_WaitTime =['WaitTimeVal01','WaitTimeVal02','WaitTimeVal03','WaitTimeVal04','WaitTimeVal05','WaitTimeVal06','WaitTimeVal07','WaitTimeVal08','WaitTimeVal09','WaitTimeVal10','WaitTimeVal11','WaitTimeVal12','WaitTimeVal13','WaitTimeVal14','WaitTimeVal15','WaitTimeVal16']
SELECTED_CHANNELS=np.array([1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1])
#SELECTED_CHANNELS=np.array([1,1,1,1,0,0,0,0,0,0,0,0,1,1,0,0])


PATH_INPUT='C:/Users/Nikon/Desktop/Lily/automatic update Element macros/20211101/target flow rate 195'
PATH_INPUT_1='C:/Users/Nikon/Desktop/Lily/automatic update Element macros'
PATH_OUTPUT='C:/Program Files/NIS-Elements/Macros/Macros for 16 channel fluidics system V1'

PATH_input_file_WaitTime=PATH_INPUT_1+'/update variable template.mac'
PATH_output_file_WaitTime=PATH_OUTPUT+'/update variable.mac'
PATH_input_file_Pressue=PATH_INPUT_1+'/macros for ND Acquisition input_FISH'
#PATH_input_file_Pressue=PATH_INPUT_1+'/macros for ND Acquisition input_test'
PATH_output_file_Pressue=PATH_OUTPUT+'/for ND acquisition'


if WASH==1:
    WaitTime=np.full([16,1],35)
    WaitTime[14,0]=65
else:
    WaitTime=np.load(PATH_INPUT+'/WaitTime.npy',allow_pickle=True)

pr_set_channels=np.load(PATH_INPUT+'/pr_set_channels.npy',allow_pickle=True)


WaitTime_temp=WaitTime
pr_set_channels_temp=pr_set_channels

WaitTime=np.full([16],300)
pr_set_channels=np.full([16],20)


c=0
for i in range (16):
    if SELECTED_CHANNELS[i]==1:
        WaitTime[i]=WaitTime_temp[c]
        pr_set_channels[i]=pr_set_channels_temp[c]
        c=c+1
    else:
        pass
    
    


pr_set_channels_hex=np.empty(16,dtype=object)
for i in range (16):
    pr_set_channels_hex[i]=hex(pr_set_channels[i]).upper()
    
replacements_ValveNum_hex=np.empty(16,dtype=object)
for i in range (16):
    replacements_ValveNum_hex[i]=hex(int(VALVE_NUMBER[i])).upper()




with open(PATH_input_file_WaitTime,encoding='utf-8') as infile, open(PATH_output_file_WaitTime, 'w+',encoding='utf-8') as outfile:
    for line in infile:
        for i, src in enumerate(replacements_WaitTime):
            line = line.replace(src, src+'='+str(int(np.ceil(WaitTime[i]))))
            
        outfile.write(line)
        
infile.close()
outfile.close()        

for i in range (16):
    i=i+1
    PATH_input_file_Pressue_temp=PATH_input_file_Pressue+'/channel_'+str(i)+'.mac'
    PATH_output_file_Pressue_temp=PATH_output_file_Pressue+'/channel_'+str(i)+'.mac'
    
    with open(PATH_input_file_Pressue_temp,encoding='utf-8') as infile, open(PATH_output_file_Pressue_temp, 'w+',encoding='utf-8') as outfile:
        for line in infile:
            line = line.replace('Pressure_HEX','"'+'\\x78'+'\\x'+pr_set_channels_hex[i-1][2:]+'"')
            outfile.write(line)
    infile.close()
    outfile.close() 

i=13
PATH_input_file_Pressue_temp=PATH_input_file_Pressue+'/channel_DB_sit.mac'
PATH_output_file_Pressue_temp=PATH_output_file_Pressue+'/channel_DB_sit.mac'    
with open(PATH_input_file_Pressue_temp,encoding='utf-8') as infile, open(PATH_output_file_Pressue_temp, 'w+',encoding='utf-8') as outfile:
    for line in infile:
        line = line.replace('Pressure_HEX','"'+'\\x78'+'\\x'+pr_set_channels_hex[i-1][2:]+'"')
        outfile.write(line)
infile.close()
outfile.close() 
    
i=14
PATH_input_file_Pressue_temp=PATH_input_file_Pressue+'/channel_PBS_sit.mac'
PATH_output_file_Pressue_temp=PATH_output_file_Pressue+'/channel_PBS_sit.mac'    
with open(PATH_input_file_Pressue_temp,encoding='utf-8') as infile, open(PATH_output_file_Pressue_temp, 'w+',encoding='utf-8') as outfile:
    for line in infile:
        line = line.replace('Pressure_HEX','"'+'\\x78'+'\\x'+pr_set_channels_hex[i-1][2:]+'"')
        outfile.write(line)
infile.close()
outfile.close() 